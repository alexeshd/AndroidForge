package com.example.photographeragenda

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.SettingsBackupRestore
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalLayoutDirection
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class Booking(
    val id: Long, val client: String, val phone: String, val type: String,
    val date: String, val time: String, val location: String,
    val price: Double, val deposit: Double, val team: String, val notes: String
) { val remaining: Double get() = (price - deposit).coerceAtLeast(0.0) }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createReminderChannel()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 701)
        }
        setContent { AgendaApp() }
    }
    private fun createReminderChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("booking_reminders", "تذكير بمواعيد التصوير", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}

@Composable
private fun AgendaApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("photographer_agenda", Context.MODE_PRIVATE) }
    var bookings by remember { mutableStateOf(loadBookings(prefs)) }
    var team by remember { mutableStateOf(loadTeam(prefs)) }
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var editingBooking by remember { mutableStateOf<Booking?>(null) }
    var showTeamAdd by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) try {
            val root = JSONObject().put("version", 1).put("bookings", bookingsToJson(bookings)).put("team", JSONArray().apply { team.forEach { put(it) } })
            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(root.toString(2)) }
            message = "تم حفظ النسخة الاحتياطية بنجاح"
        } catch (_: Exception) { message = "حصل خطأ أثناء حفظ النسخة الاحتياطية" }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) try {
            val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
            val root = JSONObject(raw)
            bookings = jsonToBookings(root.optJSONArray("bookings") ?: JSONArray())
            team = (root.optJSONArray("team") ?: JSONArray()).let { a -> (0 until a.length()).map { a.getString(it) } }
            saveAll(prefs, bookings, team)
            message = "تم استرجاع النسخة الاحتياطية"
        } catch (_: Exception) { message = "الملف غير صالح أو لا يمكن قراءته" }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF176B62), secondary = androidx.compose.ui.graphics.Color(0xFFE0A44B), background = androidx.compose.ui.graphics.Color(0xFFF5F7F6))) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Scaffold(
                topBar = { Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp)) {
                    Text("أجندة المصور", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("كل حجوزاتك وحساباتك في مكان واحد", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } },
                bottomBar = { NavigationBar {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("الحجوزات") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Payments, null) }, label = { Text("الحسابات") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Groups, null) }, label = { Text("الفريق") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.SettingsBackupRestore, null) }, label = { Text("النسخ") })
                } },
                floatingActionButton = {
                    if (tab == 0) FloatingActionButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, contentDescription = "إضافة حجز") }
                    if (tab == 2) FloatingActionButton(onClick = { showTeamAdd = true }) { Icon(Icons.Default.Add, contentDescription = "إضافة فرد للفريق") }
                }
            ) { padding ->
                Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                    when (tab) {
                        0 -> {
                            val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                SummaryCard("إجمالي الحجوزات", bookings.size.toString(), Modifier.weight(1f))
                                SummaryCard("مواعيد اليوم", bookings.count { it.date == today }.toString(), Modifier.weight(1f))
                            }
                            Spacer(Modifier.height(12.dp))
                            if (bookings.isEmpty()) EmptyState("لسه مفيش حجوزات", "اضغط على علامة + وسجّل أول ميعاد تصوير")
                            else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
                                items(bookings.sortedWith(compareBy<Booking> { it.date }.thenBy { it.time }), key = { it.id }) { b ->
                                    BookingCard(b, onEdit = { editingBooking = b }, onDelete = {
                                        bookings = bookings.filterNot { it.id == b.id }; saveAll(prefs, bookings, team)
                                    })
                                }
                            }
                        }
                        1 -> {
                            val total = bookings.sumOf { it.price }; val paid = bookings.sumOf { it.deposit }; val due = bookings.sumOf { it.remaining }
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                                SummaryCard("إجمالي قيمة الشغل", money(total), Modifier.fillMaxWidth())
                                SummaryCard("إجمالي العربون المسجل", money(paid), Modifier.fillMaxWidth())
                                SummaryCard("المبالغ المتبقية", money(due), Modifier.fillMaxWidth())
                                Text("تفاصيل الحسابات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                                    items(bookings.sortedBy { it.date }) { b ->
                                        Card(shape = RoundedCornerShape(16.dp)) { Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                            Text(b.client, fontWeight = FontWeight.Bold)
                                            Text("${b.type} • ${b.date} ${b.time}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Spacer(Modifier.height(6.dp))
                                            Text("السعر: ${money(b.price)}  |  العربون: ${money(b.deposit)}")
                                            Text("المتبقي: ${money(b.remaining)}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                                        } }
                                    }
                                }
                            }
                        }
                        2 -> {
                            Text("المصورون والمساعدون", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            if (team.isEmpty()) EmptyState("فريقك لسه فاضي", "اضغط + لإضافة أسماء المصورين والمساعدين")
                            else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
                                items(team) { person -> Card(shape = RoundedCornerShape(14.dp)) { Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(person, Modifier.weight(1f), fontWeight = FontWeight.Medium)
                                    TextButton(onClick = { team = team.filterNot { it == person }; saveAll(prefs, bookings, team) }) { Text("حذف") }
                                } } }
                            }
                            Text("اكتب أسماء الفريق في بيانات الحجز لربطهم بكل شغل.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        else -> {
                            Card(shape = RoundedCornerShape(18.dp)) { Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("النسخ الاحتياطي", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text("صدّر الحجوزات والفريق في ملف JSON واحتفظ به في مكان آمن. تقدر تسترجعه من نفس الشاشة.")
                                Button(onClick = { exportLauncher.launch("agendat_almosawer_backup.json") }, modifier = Modifier.fillMaxWidth()) { Text("تصدير نسخة احتياطية") }
                                OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/*")) }, modifier = Modifier.fillMaxWidth()) { Text("استرجاع نسخة احتياطية") }
                                Text("مهم: الاسترجاع يستبدل البيانات الحالية بالبيانات الموجودة في الملف.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                            } }
                            Spacer(Modifier.height(14.dp))
                            Text("بياناتك محفوظة محليًا على الموبايل. احتفظ بنسخة احتياطية بشكل دوري.", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
    if (showAdd) AddBookingDialog(team = team, existing = bookings, onDismiss = { showAdd = false }, onSave = { b ->
        bookings = bookings + b; saveAll(prefs, bookings, team); scheduleReminder(context, b); showAdd = false
    })
    editingBooking?.let { current ->
        AddBookingDialog(team = team, existing = bookings, initial = current, onDismiss = { editingBooking = null }, onSave = { updated ->
            bookings = bookings.map { if (it.id == current.id) updated else it }
            saveAll(prefs, bookings, team)
            scheduleReminder(context, updated)
            editingBooking = null
        })
    }
    if (showTeamAdd) AddTeamDialog(onDismiss = { showTeamAdd = false }, onSave = { name -> if (name.isNotBlank() && name !in team) { team = team + name.trim(); saveAll(prefs, bookings, team) }; showTeamAdd = false })
    if (message.isNotBlank()) AlertDialog(onDismissRequest = { message = "" }, confirmButton = { TextButton(onClick = { message = "" }) { Text("تمام") } }, text = { Text(message) })
}

@Composable private fun SummaryCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp)) { Text(title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(6.dp)); Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) }
    }
}

@Composable private fun EmptyState(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(top = 55.dp, bottom = 50.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.CalendarMonth, null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(12.dp)); Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp)); Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable private fun BookingCard(b: Booking, onEdit: () -> Unit, onDelete: () -> Unit) {
    Card(shape = RoundedCornerShape(18.dp)) { Column(Modifier.fillMaxWidth().padding(16.dp)) {
        Row(verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) { Text(b.client, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Text(b.type, color = MaterialTheme.colorScheme.primary) }
            Text("${b.date}\n${b.time}", textAlign = androidx.compose.ui.text.style.TextAlign.End, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
        }
        if (b.phone.isNotBlank()) Text("📞 ${b.phone}")
        if (b.location.isNotBlank()) Text("📍 ${b.location}")
        if (b.team.isNotBlank()) Text("الفريق: ${b.team}")
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("السعر ${money(b.price)} • العربون ${money(b.deposit)}", style = MaterialTheme.typography.bodySmall); Text("المتبقي ${money(b.remaining)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) }; TextButton(onClick = onEdit) { Text("تعديل") }; TextButton(onClick = onDelete) { Text("حذف") } }
        if (b.notes.isNotBlank()) Text("ملاحظات: ${b.notes}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    } }
}

@Composable private fun AddBookingDialog(team: List<String>, existing: List<Booking>, initial: Booking? = null, onDismiss: () -> Unit, onSave: (Booking) -> Unit) {
    var client by remember { mutableStateOf(initial?.client ?: "") }; var phone by remember { mutableStateOf(initial?.phone ?: "") }; var type by remember { mutableStateOf(initial?.type ?: "فرح") }
    var date by remember { mutableStateOf(initial?.date ?: SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }; var time by remember { mutableStateOf(initial?.time ?: "18:00") }
    var location by remember { mutableStateOf(initial?.location ?: "") }; var price by remember { mutableStateOf(initial?.price?.toString() ?: "") }; var deposit by remember { mutableStateOf(initial?.deposit?.toString() ?: "0") }
    var assigned by remember { mutableStateOf(initial?.team ?: "") }; var notes by remember { mutableStateOf(initial?.notes ?: "") }; var error by remember { mutableStateOf("") }
    val types = listOf("فرح", "خطوبة", "سيشن", "عيد ميلاد", "منتج", "مناسبة", "أخرى")
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (initial == null) "إضافة حجز جديد" else "تعديل الحجز") }, text = {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 520.dp)) {
            item { OutlinedTextField(client, { client = it }, label = { Text("اسم العميل *") }, singleLine = true) }
            item { OutlinedTextField(phone, { phone = it }, label = { Text("رقم التليفون") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)) }
            item { Text("نوع التصوير"); Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { types.take(4).forEach { t -> FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t) }) } } }
            item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(date, { date = it }, label = { Text("التاريخ YYYY-MM-DD") }, modifier = Modifier.weight(1.2f), singleLine = true); OutlinedTextField(time, { time = it }, label = { Text("الساعة") }, modifier = Modifier.weight(0.8f), singleLine = true) } }
            item { Text("اكتب التاريخ بالشكل 2026-12-31") }
            item { OutlinedTextField(location, { location = it }, label = { Text("مكان التصوير") }, singleLine = true) }
            item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(price, { price = it }, label = { Text("السعر بالجنيه") }, modifier = Modifier.weight(1f), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)); OutlinedTextField(deposit, { deposit = it }, label = { Text("العربون") }, modifier = Modifier.weight(1f), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)) } }
            if (team.isNotEmpty()) item { Text("الفريق المشارك (اختياري)"); team.forEach { person -> FilterChip(selected = assigned.split(", ").contains(person), onClick = { assigned = if (assigned.split(", ").contains(person)) assigned.split(", ").filter { it != person }.joinToString(", ") else listOf(assigned, person).filter { it.isNotBlank() }.joinToString(", ") }, label = { Text(person) }) } }
            item { OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") }, minLines = 2) }
            if (error.isNotBlank()) item { Text(error, color = MaterialTheme.colorScheme.error) }
        }
    }, confirmButton = { TextButton(onClick = {
        val p = price.toDoubleOrNull(); val d = deposit.toDoubleOrNull() ?: 0.0
        if (client.isBlank()) error = "اكتب اسم العميل"
        else if (!date.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) error = "اكتب التاريخ بالشكل YYYY-MM-DD"
        else if (p == null || p < 0 || d < 0 || d > p) error = "راجع السعر والعربون؛ العربون لا يمكن أن يتجاوز السعر"
        else if (existing.any { it.id != initial?.id && it.date == date && it.time == time }) error = "تنبيه: يوجد حجز في نفس التاريخ والساعة. غيّر الميعاد أو راجعه قبل الحفظ."
        else onSave(Booking(initial?.id ?: System.currentTimeMillis(), client.trim(), phone.trim(), type, date, time, location.trim(), p, d, assigned, notes.trim()))
    }) { Text(if (initial == null) "حفظ الحجز" else "حفظ التعديلات") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable private fun AddTeamDialog(onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إضافة فرد للفريق") }, text = { OutlinedTextField(name, { name = it }, label = { Text("اسم المصور أو المساعد") }, singleLine = true) }, confirmButton = { TextButton(onClick = { onSave(name) }) { Text("إضافة") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

private fun money(n: Double) = String.format(Locale.US, "%.2f ج.م", n)
private fun bookingsToJson(list: List<Booking>) = JSONArray().apply { list.forEach { b -> put(JSONObject().put("id", b.id).put("client", b.client).put("phone", b.phone).put("type", b.type).put("date", b.date).put("time", b.time).put("location", b.location).put("price", b.price).put("deposit", b.deposit).put("team", b.team).put("notes", b.notes)) } }
private fun jsonToBookings(a: JSONArray): List<Booking> = (0 until a.length()).map { i -> val o = a.getJSONObject(i); Booking(o.optLong("id", System.currentTimeMillis() + i), o.optString("client"), o.optString("phone"), o.optString("type", "أخرى"), o.optString("date"), o.optString("time"), o.optString("location"), o.optDouble("price"), o.optDouble("deposit"), o.optString("team"), o.optString("notes")) }
private fun loadBookings(p: android.content.SharedPreferences): List<Booking> = try { jsonToBookings(JSONArray(p.getString("bookings", "[]"))) } catch (_: Exception) { emptyList() }
private fun loadTeam(p: android.content.SharedPreferences): List<String> = try { val a = JSONArray(p.getString("team", "[]")); (0 until a.length()).map { a.getString(it) } } catch (_: Exception) { emptyList() }
private fun saveAll(p: android.content.SharedPreferences, bookings: List<Booking>, team: List<String>) { p.edit().putString("bookings", bookingsToJson(bookings).toString()).putString("team", JSONArray().apply { team.forEach { put(it) } }.toString()).apply() }

private fun scheduleReminder(context: Context, b: Booking) {
    try {
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse("${b.date} ${b.time}") ?: return
        val trigger = date.time - 24L * 60 * 60 * 1000
        if (trigger <= System.currentTimeMillis()) return
        val intent = Intent(context, ReminderReceiver::class.java).putExtra("client", b.client).putExtra("date", b.date).putExtra("time", b.time).putExtra("location", b.location)
        val pending = PendingIntent.getBroadcast(context, (b.id % Int.MAX_VALUE).toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
    } catch (_: Exception) { }
}
