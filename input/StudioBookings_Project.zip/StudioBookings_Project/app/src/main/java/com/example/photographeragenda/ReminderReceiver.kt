package com.example.photographeragenda

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
        val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val client = intent.getStringExtra("client") ?: "عميل"
        val date = intent.getStringExtra("date") ?: ""
        val time = intent.getStringExtra("time") ?: ""
        val location = intent.getStringExtra("location") ?: ""
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(context, "booking_reminders") else Notification.Builder(context)
        notification.setSmallIcon(android.R.drawable.ic_menu_my_calendar).setContentTitle("تذكير بموعد تصوير").setContentText("$client — $date الساعة $time").setStyle(Notification.BigTextStyle().bigText("العميل: $client\nالتاريخ: $date\nالساعة: $time\nالمكان: $location")).setContentIntent(open).setAutoCancel(true)
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification.build())
    }
}
